package mo.n5la.server;

import mo.n5la.utils.FLog;
import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

/**************************
 * BUILD ON Android Studio
 * TELEGRAM : @n5laVIP
 * *************************/

public class ApiServer {

    public static ApiServer AppChecker;

    static {
        try {
            System.loadLibrary("n5la");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    public static native String URLabufahad();
    public static native String getOwner();
    public static native String getTelegram();
    public static native String FixCrash();
    public static native String activity();
    public static native String ApiKeyBox();
    public static native String EXP();
    public static native String URLJSON();
    private static native boolean nativeVerifyAppLabel(String appLabel);




    public static boolean verifyAppLabel(Activity activity) {
        try {
            ApplicationInfo appInfo = activity.getPackageManager().getApplicationInfo(activity.getPackageName(), 0);
            String appLabel = (String) activity.getPackageManager().getApplicationLabel(appInfo);
            return nativeVerifyAppLabel(appLabel);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}

