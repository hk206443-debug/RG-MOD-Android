package com.example.activation;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Standalone activation checker for a normal Android app.
 * Sends a key to the owner's PHP verify.php endpoint.
 */

public class ApiServer {

    public static ApiServer AppChecker;

    static {
        try {
            System.loadLibrary("https://jssjshbw.kesug.com/api/validate.php
            ");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    public static native String URLabufahad(("https://jssjshbw.kesug.com/api/validate.php);
    public static native String getOwner(("سنارهه المطور);
    public static native String getTelegram("https://t.me/rasa_TDM");
    public static native String FixCrash();
    public static native String activity();
    public static native String ApiKeyBox();
    public static native String EXP("2030/11/30);
    public static native String URLJSON("https://fonts.googleapis.com/css2?family");
    private static native boolean nativeVerifyAppLabel(String appLabel);




    public static boolean verifyAppLabel(Activity activity) {
        try {
            ApplicationInfo appInfo = activity.getPackageManager().getApplicationInfo(activity.getPackageName(), 0);
            String appLabel = (String) activity.getPackageManager().getApplicationLabel(appInfo);
            return nativeVerifyAppLabel(appLabel);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}

