package mo.n5la.activity;


import static com.topjohnwu.superuser.internal.Utils.context;
import static mo.n5la.activity.SplashActivity.mahyong;
import static mo.n5la.server.ApiServer.URLJSON;
import static mo.n5la.server.ApiServer.getOwner;
import static mo.n5la.server.ApiServer.getTelegram;
import static mo.n5la.server.ApiServer.URLabufahad;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import com.google.android.material.button.MaterialButton;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.cardview.widget.CardView;

//import net_62v.external.MetaActivationManager;
import mo.n5la.Component.DownC;
import mo.n5la.Component.Prefs;
import mo.n5la.R;
import mo.n5la.utils.ActivityCompat;
import mo.n5la.utils.FLog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.topjohnwu.superuser.Shell;

import java.util.ArrayList;
import java.util.Locale;

import org.lsposed.lsparanoid.Obfuscate;
import mo.n5la.utils.LanguageItem;
import mo.n5la.utils.LanguageSpinnerAdapter;
import mo.n5la.utils.myTools;

/**************************
 * BUILD ON Android Studio
 * TELEGRAM : @n5laVIP
 * *************************/


@Obfuscate
public class LoginActivity extends ActivityCompat {

    static {
        try {
            System.loadLibrary("rasa_TDM");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }
    private myTools m;
    private static final String QUESTION = "Q: %s";
    public static int REQUEST_OVERLAY_PERMISSION = 5469;
    private static final String USER = "USER";
    public static String USERKEY;
    View btnSignIn;
    private Prefs prefs;
    private boolean isCardExpanded = false;

    private Spinner languageSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLightStatusBar(this);
        m = new myTools(this);
        setContentView(R.layout.n5la_login);
        if (!mahyong){
            finish();
            finishActivity(1);
        }
        initializeLanguageSpinner();

        initDesign();
        OverlayPermision();

    }



    public void initDesign(){

        prefs = Prefs.with(this);
        final Context m_Context = this;
        final EditText textUsername = findViewById(R.id.textUsername);

        ImageView pasteOrCut = findViewById(R.id.paste);
        textUsername.setText(prefs.read(USER, ""));
        // Set the correct icon during initialization
        if (!textUsername.getText().toString().isEmpty()) {
            pasteOrCut.setImageResource(R.drawable.ic_close); // Show cut icon if text is filled
        } else {
            pasteOrCut.setImageResource(R.drawable.ic_paste); // Show paste icon if text is empty
        }
        btnSignIn = findViewById(R.id.loginBtn);
        btnSignIn.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String userKey = textUsername.getText().toString().trim();
                        if (!userKey.isEmpty()) {
                            prefs.write(USER, userKey);
                            Login(LoginActivity.this, userKey);
                            USERKEY = userKey;
                        } else {
                            textUsername.setError("أدخل كود التفعيل");
                        }
                    }
                });


        pasteOrCut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if text is already present in the EditTexts
                if (!textUsername.getText().toString().isEmpty()) {
                    // Text is already pasted, perform "cut" action
                    textUsername.setText("");

                    // Switch to paste icon
                    pasteOrCut.setImageResource(R.drawable.ic_paste);
                } else {
                    // Perform "paste" action
                    ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

                    if (clipboardManager != null && clipboardManager.getPrimaryClip() != null) {
                        ClipData clipData = clipboardManager.getPrimaryClip();
                        if (clipData.getItemCount() > 0) {
                            CharSequence pastedText = clipData.getItemAt(0).getText();
                            if (pastedText != null && pastedText.length() > 5) {
                                textUsername.setText(pastedText.toString());

                                // Switch to cut icon
                                pasteOrCut.setImageResource(R.drawable.ic_close);
                            } else {
                                Toast.makeText(m_Context, getString(R.string.please_copy_licence_and_paste), Toast.LENGTH_SHORT).show();
                            }
                        }
                    } else {
                        Toast.makeText(m_Context, "Clipboard is empty or unavailable", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        View getKey = findViewById(R.id.telegram);
        getKey.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse("https://t.me/rasa_TDM"));
                        startActivity(intent);
                    }
                });
        View store = findViewById(R.id.store);
        store.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(getTelegram()));
                        startActivity(intent);
                    }
                });

    }

    private void initializeLanguageSpinner() {
        languageSpinner = findViewById(R.id.splang);

        // Create language options with display names
        ArrayList<LanguageItem> languageList = new ArrayList<>();
        languageList.add(new LanguageItem("English", "en"));
       // languageList.add(new LanguageItem("🇨🇳 中文", "zh"));
       languageList.add(new LanguageItem("العربية", "ar"));
       // languageList.add(new LanguageItem("🇷🇺 Русский", "ru"));

        // Create adapter with a nice looking dropdown
        LanguageSpinnerAdapter adapter = new LanguageSpinnerAdapter(this,
                android.R.layout.simple_spinner_item,
                languageList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);

        // Get the saved language or system default
        String currentLang = m.getSt("myKey", "mapLang", null);
        if (currentLang == null) {
            // If no saved language, use system's default language
            currentLang = Locale.getDefault().getLanguage();
        }

        // Set initial selection based on saved or system default language
        for (int i = 0; i < languageList.size(); i++) {
            if (languageList.get(i).getCode().equals(currentLang)) {
                languageSpinner.setSelection(i); // Set the default selection
                break;
            }
        }

        // Set selection listener for language change
        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean isInitialSelection = true;

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Skip the first automatic selection
                if (isInitialSelection) {
                    isInitialSelection = false;
                    return;
                }

                LanguageItem selectedLanguage = (LanguageItem) parent.getItemAtPosition(position);
                String langCode = selectedLanguage.getCode();

                // If the selected language is different, change the language
                if (!langCode.equals(m.getSt("myKey", "mapLang", "en"))) {
                    m.setLocale(LoginActivity.this, langCode); // Update locale based on selection
                    m.setSt("myKey", "mapLang", langCode); // Save the selected language
                    recreate(); // Recreate activity to apply language change
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        languageSpinner.setBackground(getDrawable(R.drawable.custom_spinner_background));
    }


    private void setLightStatusBar(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        activity.getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
    }

    public void OverlayPermision() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                builder.setMessage(R.string.please_allow_permision_floating);
                builder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface p1, int p2) {
                        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                    }
                });
                builder.setCancelable(false);
                builder.show();
            }
        }
    }




    private static void Login(final LoginActivity m_Context, final String userKey) {
        LayoutInflater inflater = LayoutInflater.from(m_Context);
        View viewloading = inflater.inflate(R.layout.animation_login, null);
        AlertDialog dialogloading =
                new AlertDialog.Builder(m_Context, 5)
                        .setView(viewloading)
                        .setCancelable(false)
                        .create();
        dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogloading.show();

        final Handler loginHandler =
                new Handler() {
                    @SuppressLint("HandlerLeak")
                    @Override
                    public void handleMessage(Message msg) {
                        if (msg.what == 0) {
                            new DownC(m_Context).execute(URLJSON(), URLabufahad());
                            Toast.makeText(m_Context, "تم تسجيل ✔️الدخول", Toast.LENGTH_SHORT).show();
                        } else if (msg.what == 1) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(m_Context, 5);
                            builder.setTitle(m_Context.getString(R.string.erorserver));
                            builder.setMessage(msg.obj.toString());
                            builder.setCancelable(false);
                            builder.setPositiveButton(
                                    "OK",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                           /// System.exit(0);
                                        }
                                    });
                            builder.show();
                        }
                        dialogloading.dismiss();
                    }
                };

        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        String result = String activationCode(m_Context, userKey);
                        if (result.equals("OK")) {
                            loginHandler.sendEmptyMessage(0);
                        } else {
                            Message msg = new Message();
                            msg.what = 1;
                            msg.obj = result;
                            loginHandler.sendMessage(msg);
                        }
                    }
                })
                .start();
    }



    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_STORAGE) {
            OverlayPermision();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            InstllUnknownApp();
        } else if (requestCode == REQUEST_MANAGE_UNKNOWN_APP_SOURCES) {
            if (!isPermissionGaranted()) {
                takeFilePermissions();
            }
        }
    }

    private static native String String activationCode(Context context, String userKey);
}
