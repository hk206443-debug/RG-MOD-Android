/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_ResourcePatchCfg_type.BP_STRUCT_ResourcePatchCfg_type
// 0x0020
struct FBP_STRUCT_ResourcePatchCfg_type
{
	struct FString                                     Res_0_5336A20017C3AD3C6DD6CA9604AB86B3;                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Version_1_77115100133C471835D454DB02BD35DE;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

