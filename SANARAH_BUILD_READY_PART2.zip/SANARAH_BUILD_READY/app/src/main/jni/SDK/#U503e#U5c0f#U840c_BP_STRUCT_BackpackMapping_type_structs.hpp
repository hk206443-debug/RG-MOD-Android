/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:57 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_BackpackMapping_type.BP_STRUCT_BackpackMapping_type
// 0x0020
struct FBP_STRUCT_BackpackMapping_type
{
	int                                                ItemIDLv1_0_21A3A0400039E85B0FB4B5AE02FC6161;             // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ItemIDLv3_4_21A5A0C00039E85D0FB4B5A802FC6163;             // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SkinID_5_0CC9E5002CE60FA0348CD8800DC46CC4;                // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ItemIDLv2_6_21A4A0800039E85C0FB4B5AF02FC6162;             // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SkinItemIDLv1_8_54E5658067900F920ABA96CA085B62E1;         // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SkinItemIDLv3_9_54E7660067900F940ABA96CC085B62E3;         // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                LobbyShowItemID_10_2F22E9C00E7C61770577495A0A75F1B4;      // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SkinItemIDLv2_11_54E665C067900F930ABA96CD085B62E2;        // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

