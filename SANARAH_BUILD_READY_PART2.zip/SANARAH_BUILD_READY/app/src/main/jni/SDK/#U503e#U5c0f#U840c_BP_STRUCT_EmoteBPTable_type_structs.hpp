/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_EmoteBPTable_type.BP_STRUCT_EmoteBPTable_type
// 0x0088
struct FBP_STRUCT_EmoteBPTable_type
{
	struct FString                                     Path_0_247605C000C1809320361CC70BC26958;                  // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CName_1_20BFF38058E1993E3181765E0C385985;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_2_6D1FE5C03D4B9B6365DA363A01FBC3D4;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     LobbyPath_3_17CBE3C0186812E1377BBB6D07222BE8;             // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LobbyEmoteAdapt_4_6274998039C4B44E5D4A1AFE0DB5A954;       // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BattleLowPath_5_4F3B89400282AC756B607A450BF84618;         // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PathHigh_6_050CC5C0133BD80B2E9B638909572DB8;              // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EmoteCollisionBox_7_694DF6406325C17B04D93B540C600578;     // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EmoteCollisionCenterOffset_8_1BBE3E0042190C225D66B4B007074504;// 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

