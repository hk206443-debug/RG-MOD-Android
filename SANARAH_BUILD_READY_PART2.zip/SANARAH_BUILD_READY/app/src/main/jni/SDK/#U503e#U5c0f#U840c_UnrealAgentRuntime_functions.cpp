/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:54 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Functions
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.ResolveSpline
// (Final, Native, Public, BlueprintCallable, BlueprintPure, Const)
// Parameters:
// class USplineComponent*        ReturnValue                    (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)

class USplineComponent* UPCGSplineTubeMeshComponent::ResolveSpline()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.ResolveSpline");

	UPCGSplineTubeMeshComponent_ResolveSpline_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.RefreshTubePhysicsCollision
// (Final, Native, Public, BlueprintCallable)

void UPCGSplineTubeMeshComponent::RefreshTubePhysicsCollision()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.RefreshTubePhysicsCollision");

	UPCGSplineTubeMeshComponent_RefreshTubePhysicsCollision_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.RebuildTubeMesh
// (Final, Native, Public, BlueprintCallable)

void UPCGSplineTubeMeshComponent::RebuildTubeMesh()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.RebuildTubeMesh");

	UPCGSplineTubeMeshComponent_RebuildTubeMesh_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

