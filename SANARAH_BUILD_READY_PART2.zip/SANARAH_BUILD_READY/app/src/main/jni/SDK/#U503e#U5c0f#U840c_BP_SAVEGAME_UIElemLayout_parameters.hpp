/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Parameters
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function BP_SAVEGAME_UIElemLayout.BP_SAVEGAME_UIElemLayout_C.BPStructToCPP
struct UBP_SAVEGAME_UIElemLayout_C_BPStructToCPP_Params
{
	struct FBP_STRUCT_UIElemLayoutDetail               In;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
	struct FUIElemLayoutDetail                         Out;                                                      // (Parm, OutParm)
};

// Function BP_SAVEGAME_UIElemLayout.BP_SAVEGAME_UIElemLayout_C.CPPStructToBP
struct UBP_SAVEGAME_UIElemLayout_C_CPPStructToBP_Params
{
	struct FUIElemLayoutDetail                         In;                                                       // (BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
	struct FBP_STRUCT_UIElemLayoutDetail               Out;                                                      // (Parm, OutParm)
};

}

