SANARAH Android project - build configuration repair

Project root: SanarahProject/
Gradle command: ./gradlew :app:assembleDebug
Expected debug APK: app/build/outputs/apk/debug/

This repair restores the missing root Gradle files, places the Gradle launcher
at the project root, adds gradle-wrapper.properties, and removes machine-local
SDK configuration and private signing artifacts from this distributable copy.

Build requirements:
- JDK 17
- Android SDK platform 34
- Android NDK 25.2.9519653

A successful APK build has NOT been verified in this environment. Additional
source/dependency/native compiler errors may still appear during the first build.
For a privately signed release build, configure signing.properties and your own
keystore locally; do not commit passwords or keystore files to a public repo.
