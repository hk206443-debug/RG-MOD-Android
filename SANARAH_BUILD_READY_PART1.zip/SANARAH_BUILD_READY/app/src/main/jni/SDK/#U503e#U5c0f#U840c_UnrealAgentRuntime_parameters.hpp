/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:54 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Parameters
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.ResolveSpline
struct UPCGSplineTubeMeshComponent_ResolveSpline_Params
{
	class USplineComponent*                            ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.RefreshTubePhysicsCollision
struct UPCGSplineTubeMeshComponent_RefreshTubePhysicsCollision_Params
{
};

// Function UnrealAgentRuntime.PCGSplineTubeMeshComponent.RebuildTubeMesh
struct UPCGSplineTubeMeshComponent_RebuildTubeMesh_Params
{
};

}

