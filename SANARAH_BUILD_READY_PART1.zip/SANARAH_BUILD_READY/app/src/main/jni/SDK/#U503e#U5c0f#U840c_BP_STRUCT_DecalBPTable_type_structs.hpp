/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_DecalBPTable_type.BP_STRUCT_DecalBPTable_type
// 0x0060
struct FBP_STRUCT_DecalBPTable_type
{
	int                                                ID_0_0CAD9D8055C0CD6A25A0DCEE0A0553D4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Path_1_0033FD807638E0C45A483151055262A8;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CName_2_6D7E0B40638C94B731ACB8980538E865;                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DefaultTexturePath_3_3BA6EB00368C49AC4F31B2080CB16AE8;    // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FlipBookTexturePath_4_75157F4004E82529477143F20510B968;   // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                soundID_5_6F0D27C03EADFE7B44B5857B0ACC1DD4;               // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x004C(0x0004) MISSED OFFSET
	struct FString                                     soundPath_6_09E147C024FF3AFD468FAA630C1C6268;             // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

