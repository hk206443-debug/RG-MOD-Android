/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_TransSupportConfig_JK_type.BP_STRUCT_TransSupportConfig_JK_type
// 0x0038
struct FBP_STRUCT_TransSupportConfig_JK_type
{
	struct FString                                     languageCode_0_522E49002C2C60AE700EB3710A85F6D5;          // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     abbreviation_1_383E76C0511890B155CEDC5000FC0B5E;          // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                languageID_2_64A28D80497B830E04CE3D52037A85A4;            // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               isSupported_3_24C9E1C053F6E8A95BD1A1D30BC1D3A4;           // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0025(0x0003) MISSED OFFSET
	struct FString                                     displayName_4_766D5700151549701BF7326D0E448FF5;           // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

