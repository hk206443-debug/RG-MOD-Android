/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:57 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Enums
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedEnum EnumAvatarForceGender.EnumAvatarForceGender
enum class EnumAvatarForceGender : uint8_t
{
	EnumAvatarForceGender__NewEnumerator0 = 0,
	EnumAvatarForceGender__NewEnumerator1 = 1,
	EnumAvatarForceGender__NewEnumerator2 = 2,
	EnumAvatarForceGender__EnumAvatarForceGender_MAX = 3
};



}

