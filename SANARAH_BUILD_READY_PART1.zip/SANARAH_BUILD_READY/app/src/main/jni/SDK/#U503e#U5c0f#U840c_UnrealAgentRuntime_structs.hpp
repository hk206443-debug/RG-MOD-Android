/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:54 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Enums
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Enum UnrealAgentRuntime.EPCGCrossSectionType
enum class EPCGCrossSectionType : uint8_t
{
	EPCGCrossSectionType__Plane    = 0,
	EPCGCrossSectionType__Tube     = 1,
	EPCGCrossSectionType__Box      = 2,
	EPCGCrossSectionType__UChannel = 3,
	EPCGCrossSectionType__Custom   = 4,
	EPCGCrossSectionType__EPCGCrossSectionType_MAX = 5
};



}

