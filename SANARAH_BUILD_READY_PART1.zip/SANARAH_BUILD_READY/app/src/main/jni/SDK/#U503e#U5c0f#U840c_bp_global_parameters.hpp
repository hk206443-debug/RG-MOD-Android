/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Parameters
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function bp_global.bp_global_C.EventShowPlatWXStartup_NoFetch
struct Abp_global_C_EventShowPlatWXStartup_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventShowPlatWXStartup
struct Abp_global_C_EventShowPlatWXStartup_Params
{
};

// Function bp_global.bp_global_C.EventShowPlatQQStartup_NoFetch
struct Abp_global_C_EventShowPlatQQStartup_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventShowPlatQQStartup
struct Abp_global_C_EventShowPlatQQStartup_Params
{
};

// Function bp_global.bp_global_C.EventShowPlatIconTips_NoFetch
struct Abp_global_C_EventShowPlatIconTips_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventShowPlatIconTips
struct Abp_global_C_EventShowPlatIconTips_Params
{
};

// Function bp_global.bp_global_C.EventSetInfo_Push_NoFetch
struct Abp_global_C_EventSetInfo_Push_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventSetInfo_Push
struct Abp_global_C_EventSetInfo_Push_Params
{
};

// Function bp_global.bp_global_C.EventSendClickGemReport_NoFetch
struct Abp_global_C_EventSendClickGemReport_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventSendClickGemReport
struct Abp_global_C_EventSendClickGemReport_Params
{
};

// Function bp_global.bp_global_C.EventSendBAReport_NoFetch
struct Abp_global_C_EventSendBAReport_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventSendBAReport
struct Abp_global_C_EventSendBAReport_Params
{
};

// Function bp_global.bp_global_C.EventGlobalUseItem_NoFetch
struct Abp_global_C_EventGlobalUseItem_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventGlobalUseItem
struct Abp_global_C_EventGlobalUseItem_Params
{
};

// Function bp_global.bp_global_C.EventGlobalCloseItemTips_NoFetch
struct Abp_global_C_EventGlobalCloseItemTips_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventGlobalCloseItemTips
struct Abp_global_C_EventGlobalCloseItemTips_Params
{
};

// Function bp_global.bp_global_C.EventFetchNationSwitch_NoFetch
struct Abp_global_C_EventFetchNationSwitch_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventFetchNationSwitch
struct Abp_global_C_EventFetchNationSwitch_Params
{
};

// Function bp_global.bp_global_C.EventFetchInfo_NoFetch
struct Abp_global_C_EventFetchInfo_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventFetchInfo
struct Abp_global_C_EventFetchInfo_Params
{
};

// Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl_NoFetch
struct Abp_global_C_EventComMsgBoxSluaClickUrl_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventComMsgBoxSluaClickUrl
struct Abp_global_C_EventComMsgBoxSluaClickUrl_Params
{
};

// Function bp_global.bp_global_C.EventClickLobbyEventGemReport_NoFetch
struct Abp_global_C_EventClickLobbyEventGemReport_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventClickLobbyEventGemReport
struct Abp_global_C_EventClickLobbyEventGemReport_Params
{
};

// Function bp_global.bp_global_C.EventCheckIfMenuOpen_NoFetch
struct Abp_global_C_EventCheckIfMenuOpen_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventCheckIfMenuOpen
struct Abp_global_C_EventCheckIfMenuOpen_Params
{
};

// Function bp_global.bp_global_C.EventAndroidQuitGame_NoFetch
struct Abp_global_C_EventAndroidQuitGame_NoFetch_Params
{
};

// Function bp_global.bp_global_C.EventAndroidQuitGame
struct Abp_global_C_EventAndroidQuitGame_Params
{
};

// Function bp_global.bp_global_C.UserConstructionScript
struct Abp_global_C_UserConstructionScript_Params
{
};

}

