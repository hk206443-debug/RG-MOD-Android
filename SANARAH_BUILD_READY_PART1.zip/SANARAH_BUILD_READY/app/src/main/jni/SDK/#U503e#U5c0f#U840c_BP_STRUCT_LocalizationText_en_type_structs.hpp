/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_LocalizationText_en_type.BP_STRUCT_LocalizationText_en_type
// 0x0010
struct FBP_STRUCT_LocalizationText_en_type
{
	struct FString                                     Value_4_28CFB4C0620053F1320833900F38F315;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

