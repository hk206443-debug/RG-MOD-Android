/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:57 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_JKMenuSwitchTable_type.BP_STRUCT_JKMenuSwitchTable_type
// 0x0008
struct FBP_STRUCT_JKMenuSwitchTable_type
{
	int                                                ID_0_349A69C07157D56340B2635C0D607D74;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_1_1FE00B006C7DA20E15B05734007ECBDE;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

