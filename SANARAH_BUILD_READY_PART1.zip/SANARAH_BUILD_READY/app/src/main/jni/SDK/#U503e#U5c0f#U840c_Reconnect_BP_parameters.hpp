/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:58 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Parameters
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function Reconnect_BP.Reconnect_BP_C.Construct
struct UReconnect_BP_C_Construct_Params
{
};

// Function Reconnect_BP.Reconnect_BP_C.ExecuteUbergraph_Reconnect_BP
struct UReconnect_BP_C_ExecuteUbergraph_Reconnect_BP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

