/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#define Gname_Offset 0xF6962D0 
#define World_Offset 0xFC3CBD8 
#define VMatrix_Offset 0xFC16A70 
#define Vworld_Offset 0xF9731A0 
#define GNames_Offset 0x9007ED0 
#define GUObject_Offset 0xF97A670 
#define GEngine_Offset 0xFC3CA70 //世界头
#define GEngine_Offset 0xFC16A70 //自CD头
#define Engine_Offset_CB 0x580A70 //自身CB头
#define GetActorArray_Offset 0xADD1ABC 
#define GNativeAndroidApp_Offset 0xF6957A8 
#define ProcessEvent_Offset 0xA90DC54 //Main
#define ProcessEvent_Offset 0x927E5A4 //Child
#define Actors_Offset 0xA0 
#define PostRer_Offset 0xACD86A4 
#define KillMessage_Offset 0x62F4868 
#define LaunchBP_Offsets 0x7A1E35C 
#define K2_DrawLine_Offset 0xB2DF4A8 
#define K2_DrawText_Offset 0xB2DF738 
#define K2_DrawTextrue_Offset 0xB2DF52C 
#define LineOfSightTo_Offset 0xABCCAD4 
#define UpdateVolleyShootParameters_Offset 0x735F948 
#define ShootBulletInner_Offset 0x73072FC //Shoot
♕︎ المطور سنارهه @سنارهه |✓| 𝑻𝒆𝒍𝒆𝒈𝒓𝒂𝒎 @rasa_TDM
