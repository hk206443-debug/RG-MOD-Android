package mo.n5la.server;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Client for the RG MOD PHP verification endpoint.
 * verify.php accepts either JSON or standard POST form data.
 */
public final class RGModApi {

    private static final String VALIDATE_URL =
            "https://jssjshbw.kesug.com/verify.php";

    private static final int CONNECT_TIMEOUT_MS = 20000;
    private static final int READ_TIMEOUT_MS = 20000;

    private RGModApi() {
    }

    public static JSONObject validateCode(String activationCode) {
        if (activationCode == null || activationCode.trim().isEmpty()) {
            return errorResult("يرجى إدخال كود التفعيل");
        }

        HttpURLConnection connection = null;

        try {
            URL url = new URL(VALIDATE_URL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setDoOutput(true);
            connection.setUseCaches(false);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty(
                    "Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "Sanarah-Android/4.0.2");
            connection.setRequestProperty("Cache-Control", "no-cache");

            // verify.php explicitly supports $_POST['code']; use that supported format.
            String form = "code=" + URLEncoder.encode(
                    activationCode.trim(), "UTF-8");
            byte[] body = form.getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);

            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
                output.flush();
            }

            int statusCode = connection.getResponseCode();
            InputStream stream = (statusCode >= 200 && statusCode < 300)
                    ? connection.getInputStream()
                    : connection.getErrorStream();

            String responseText = readResponse(stream);

            if (statusCode == HttpURLConnection.HTTP_FORBIDDEN) {
                return errorResult(
                        "السيرفر رفض الطلب (HTTP 403). ملف verify.php موجود في ملفات اللوحة ولا يمنع POST حسب محتواه؛ افحص إعدادات النطاق والاستضافة وقواعد الحماية.");
            }

            if (statusCode < 200 || statusCode >= 300) {
                return errorResult("فشل طلب التحقق من السيرفر (HTTP "
                        + statusCode + ").");
            }

            if (responseText.trim().isEmpty()) {
                return errorResult("السيرفر أرسل استجابة فارغة.");
            }

            try {
                JSONObject response = new JSONObject(responseText);
                if (!response.has("valid")) {
                    return errorResult(
                            "استجابة السيرفر لا تحتوي على الحقل valid.");
                }
                return response;
            } catch (JSONException e) {
                return errorResult(
                        "السيرفر لم يُرجع JSON صالحاً. تأكد أن النطاق يفتح ملف verify.php وأن PHP يعمل بشكل صحيح.");
            }

        } catch (Exception e) {
            String detail = e.getMessage();
            if (detail == null || detail.trim().isEmpty()) {
                detail = e.getClass().getSimpleName();
            }
            return errorResult("تعذر الاتصال بالسيرفر: " + detail);
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private static String readResponse(InputStream stream) throws Exception {
        if (stream == null) {
            return "";
        }

        StringBuilder response = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line).append('\n');
                if (response.length() > 65536) {
                    break;
                }
            }
        }
        return response.toString();
    }

    private static JSONObject errorResult(String message) {
        JSONObject result = new JSONObject();
        try {
            result.put("valid", false);
            result.put("message", message);
        } catch (JSONException ignored) {
        }
        return result;
    }
}
