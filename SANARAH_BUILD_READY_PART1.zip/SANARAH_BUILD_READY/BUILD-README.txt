SANARAH project - repaired build package

The two newer source parts were overlaid onto a working copy of the older project
so the original older ZIP files remain unchanged. Missing build support files were
restored from the older project copy:
- app/build.gradle
- app/src/main/AndroidManifest.xml
- gradle/wrapper/gradle-wrapper.jar
- app/src/main/jni/Android.mk and Application.mk
- gradle.properties

The Gradle wrapper configuration remains on Gradle 8.5. Both LoginActivity
buttons (MARKET and SUPPORT) now open https://t.me/rasa_TDM. The JNI getTelegram
URL was also changed to the same Telegram destination.

Build command:
  ./gradlew :app:assembleDebug

Requirements: JDK 17, Android SDK platform 34, and NDK 25.2.9519653.
Gradle must be able to download Gradle 8.5 and dependencies on first build.

Build verification status: not completed in this environment because network DNS
was unavailable when Gradle attempted to download from services.gradle.org.
The missing GradleWrapperMain file has been restored, but a successful APK build
has not been confirmed here.
