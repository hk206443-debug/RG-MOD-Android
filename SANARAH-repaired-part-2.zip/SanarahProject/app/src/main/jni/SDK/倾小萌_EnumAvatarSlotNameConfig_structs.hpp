/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:57 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Enums
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedEnum EnumAvatarSlotNameConfig.EnumAvatarSlotNameConfig
enum class EnumAvatarSlotNameConfig : uint8_t
{
	EnumAvatarSlotNameConfig__NewEnumerator0 = 0,
	EnumAvatarSlotNameConfig__NewEnumerator1 = 1,
	EnumAvatarSlotNameConfig__NewEnumerator2 = 2,
	EnumAvatarSlotNameConfig__NewEnumerator4 = 3,
	EnumAvatarSlotNameConfig__NewEnumerator3 = 4,
	EnumAvatarSlotNameConfig__NewEnumerator5 = 5,
	EnumAvatarSlotNameConfig__NewEnumerator6 = 6,
	EnumAvatarSlotNameConfig__NewEnumerator7 = 7,
	EnumAvatarSlotNameConfig__EnumAvatarSlotNameConfig_MAX = 8
};



}

