/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:55 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_EncryptionItem_type.BP_STRUCT_EncryptionItem_type
// 0x0024
struct FBP_STRUCT_EncryptionItem_type
{
	struct FString                                     ItemEncryptionDesc_0_399BA2402808603F271CFB4E03C1CA13;    // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ItemEncryptionName_1_737BA2C03FBE98C5185E865403C222B5;    // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_2_3E285B007414EFB844C62E11094B6174;                // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

