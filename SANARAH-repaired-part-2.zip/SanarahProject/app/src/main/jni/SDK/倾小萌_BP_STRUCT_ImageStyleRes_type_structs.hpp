/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:55 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_ImageStyleRes_type.BP_STRUCT_ImageStyleRes_type
// 0x0039
struct FBP_STRUCT_ImageStyleRes_type
{
	struct FString                                     StyleName_1_2AA758BE4A03809EB53FBB84D3485796;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ImageSize_2_96EB865D41AAAF80E29845882B51076E;             // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     ImagePath_3_827587E143D09497FBF413A233DBD394;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ImageColor_4_FEA280FC47AC19EA68EA0DA0953F26D4;            // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               IsPreLoad_5_5C2685C01538212B4D151A510E2E23E4;             // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

