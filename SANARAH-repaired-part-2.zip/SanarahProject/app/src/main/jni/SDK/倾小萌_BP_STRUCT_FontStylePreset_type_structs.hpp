/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:55 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_FontStylePreset_type.BP_STRUCT_FontStylePreset_type
// 0x0020
struct FBP_STRUCT_FontStylePreset_type
{
	struct FString                                     FontName_0_44EF324019A535D53F56006B0E9E4B85;              // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FontPath_1_008D9540303E41453F57D0D90E9C6518;              // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

