/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:57 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Parameters
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function VirtualBattleItemHandle_AvatarBP.VirtualBattleItemHandle_AvatarBP_C.GetWrapperClass
struct UVirtualBattleItemHandle_AvatarBP_C_GetWrapperClass_Params
{
	class UClass*                                      WrapperClass;                                             // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
};

// Function VirtualBattleItemHandle_AvatarBP.VirtualBattleItemHandle_AvatarBP_C.Constuct
struct UVirtualBattleItemHandle_AvatarBP_C_Constuct_Params
{
	struct FItemDefineID*                              InDefineID;                                               // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm)
};

// Function VirtualBattleItemHandle_AvatarBP.VirtualBattleItemHandle_AvatarBP_C.ExecuteUbergraph_VirtualBattleItemHandle_AvatarBP
struct UVirtualBattleItemHandle_AvatarBP_C_ExecuteUbergraph_VirtualBattleItemHandle_AvatarBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

