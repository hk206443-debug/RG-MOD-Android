package mo.n5la;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.util.Log;

import java.io.File;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

public class BoxApplication extends Application {

    private static final String TAG = "BoxApplication";
    private static BoxApplication instance;
    private boolean isInternetAvailable;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        instance = this;

        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {

                public String getHostPackageName() {
                    return base.getPackageName();
                }

                public boolean isHideRoot() {
                    return true;
                }

                public boolean isHideXposed() {
                    return true;
                }

                public boolean isEnableDaemonService() {
                    return false;
                }

                public boolean requestInstallPackage(File file) {
                    PackageInfo packageInfo = base.getPackageManager()
                            .getPackageArchiveInfo(file.getAbsolutePath(), 0);
                    return false;
                }
            });

            Log.i(TAG, "BlackBox initialized");
        } catch (Exception e) {
            Log.e(TAG, "BlackBox init failed", e);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            BlackBoxCore.get().doCreate();
            Log.i(TAG, "BoxApplication started");
        } catch (Exception e) {
            Log.e(TAG, "BlackBox create failed", e);
        }
    }

    public static BoxApplication get() {
        return instance;
    }

    public void setInternetAvailable(boolean available) {
        isInternetAvailable = available;
    }

    public boolean isInternetAvailable() {
        return isInternetAvailable;
    }
}
