InputStream stream = (statusCode >= 200 && statusCode < 300)
        ? connection.getInputStream()
        : connection.getErrorStream();

if (stream == null) {
    return errorResult("السيرفر رفض الطلب (HTTP " + statusCode + ")");
}

StringBuilder responseText = new StringBuilder();

try (BufferedReader reader = new BufferedReader(
        new InputStreamReader(stream, StandardCharsets.UTF_8))) {

    String line;

    while ((line = reader.readLine()) != null) {
        responseText.append(line);
    }
}

String responseBody = responseText.toString().trim();

// التأكد من أن استجابة السيرفر بصيغة JSON
if (responseBody.isEmpty() || !responseBody.startsWith("{")) {
    return errorResult(
            "السيرفر رفض الطلب (HTTP " + statusCode
                    + "). الاستضافة أعادت صفحة غير JSON."
    );
}

JSONObject response = new JSONObject(responseBody);

if (!response.has("valid")) {
    return errorResult("صيغة استجابة السيرفر غير صحيحة");
}

if (statusCode < 200 || statusCode >= 300) {
    String message = response.optString(
            "message",
            "السيرفر رفض الطلب (HTTP " + statusCode + ")"
    );

    return errorResult(message);
}

return response;

} catch (Exception e) {
    return errorResult("تعذر الاتصال بالسيرفر: " + e.getMessage());
} finally {
    if (connection != null) {
        connection.disconnect();
    }
}

private static JSONObject errorResult(String message) {
    JSONObject result = new JSONObject();

    try {
        result.put("valid", false);
        result.put("message", message);
    } catch (Exception ignored) {
    }

    return result;
}