SANARAH Android project - build configuration repair

Project root: SanarahProject/
Debug build: ./gradlew :app:assembleDebug
Expected APK: app/build/outputs/apk/debug/

The two supplied ZIP parts were merged. The conflicting ApiServer.java entry
was taken from part 1: the part 2 copy had an invalid package declaration,
broken string literals, and invalid native method declarations.

Build setup changes:
- Debug builds no longer fail merely because private signing.properties is absent.
- Release signing is enabled only when you provide your own local signing.properties
  and keystore. No signing password or private keystore is included.
- Removed local.properties because it contained a machine-specific Windows SDK path.
- Gradle wrapper uses Gradle 8.5; Android Gradle Plugin is 8.2.2.
- Required JDK: 17. Required Android SDK platform: 34.
- Required NDK: 25.2.9519653.

Before building, install Android SDK platform 34 and NDK 25.2.9519653,
then set the SDK location in your local environment/IDE (do not commit
local.properties).

A successful APK build has not yet been verified. Further Java/C++/NDK
compiler errors may still be reported by the first real build.
