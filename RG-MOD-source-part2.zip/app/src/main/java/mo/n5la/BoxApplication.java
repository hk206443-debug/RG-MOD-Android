package mo.n5la; 

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

import android.MetaCore.nk;

public class BoxApplication extends Application {

    private static final String TAG = "BoxApplication";
    private static BoxApplication instance;
    private boolean isInternetAvailable;

    public static String getSecretCode() {
        return "N5LA-3MK-2026";
    }

    public static String getLicenseKey() {
        return "N5LA-010-VIP";
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        instance = this;
        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {

                public String getHostPackageName() {
                    return base.getPackageName();
                }

                public boolean isHideRoot() {
                    return true;
                }

                public boolean isHideXposed() {
                    return true;
                }

                public boolean isEnableDaemonService() {
                    return false;
                }

                public boolean requestInstallPackage(File file) {
                    PackageInfo packageInfo = base.getPackageManager()
                            .getPackageArchiveInfo(file.getAbsolutePath(), 0);
                    return false;
                }
            });
            Log.i(TAG, "✅ BlackBox initialized");
        } catch (Exception e) {
            Log.e(TAG, "❌ BlackBox init failed", e);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        BlackBoxCore.get().doCreate();
        Log.i(TAG, "📦 BoxApplication started");

        new Thread(() -> {
            try {
                String secretCode = getSecretCode();
                String licenseKey = getLicenseKey();

                boolean isLicensed = nk.initialize(this, secretCode, licenseKey);

                if (isLicensed) {
                    Log.i(TAG, "✅ License is VALID");
                    String licenseInfo = nk.getLicenseInfo();
                    showSuccessToast("📊 معلومات الترخيص:\n" + licenseInfo);
                } else {
                    Log.e(TAG, "❌ License is INVALID");
                    String errorMsg = nk.getServerMessage();
                    showToast("❌ فشل الترخيص:\n" + errorMsg + "\n\nسيتم تحويلك إلى رابط الدعم");
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        openContactUrl();
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            android.os.Process.killProcess(android.os.Process.myPid());
                            System.exit(0);
                        }, 500);
                    }, 2000);
                }
            } catch (Exception e) {
                Log.e(TAG, "❌ License check error: " + e.getMessage(), e);
                showToast("⚠️ خطأ في التحقق: " + e.getMessage());
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    openContactUrl();
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(0);
                    }, 500);
                }, 2000);
            }
        }).start();
    }

   
    private void showSuccessToast(String msg) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
               
                int layoutId = getResources().getIdentifier("custom_toast", "layout", getPackageName());
                int textId = getResources().getIdentifier("toast_message", "id", getPackageName());

              
                if (layoutId == 0 || textId == 0) {
                    Log.w(TAG, "Resources not found in app package, trying library package...");
                    layoutId = getResources().getIdentifier("custom_toast", "layout", "top.niunaijun.blackbox");
                    textId = getResources().getIdentifier("toast_message", "id", "top.niunaijun.blackbox");
                }

              
                if (layoutId == 0 || textId == 0) {
                    Log.e(TAG, "Toast resources not found! layoutId=" + layoutId + ", textId=" + textId);
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    return;
                }

                LayoutInflater inflater = LayoutInflater.from(this);
                View toastView = inflater.inflate(layoutId, null);
                TextView textView = toastView.findViewById(textId);
                if (textView != null) {
                    textView.setText(msg);
                }

                Toast toast = new Toast(getApplicationContext());
                toast.setDuration(Toast.LENGTH_LONG);
                toast.setView(toastView);
                toast.show();
            } catch (Exception e) {
                Log.e(TAG, "Error showing fancy toast", e);
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void showToast(String msg) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        );
    }

    private void openContactUrl() {
        try {
            String url = nk.getContactUrl();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Log.e(TAG, "❌ Failed to open contact URL", e);
        }
    }

    public static BoxApplication get() {
        return instance;
    }

    public void setInternetAvailable(boolean available) {
        isInternetAvailable = available;
    }

    public boolean isInternetAvailable() {
        return isInternetAvailable;
    }

    public static boolean isLicenseValid() {
        return nk.getActivatedSdk();
    }
}