/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:54 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Parameters
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.GetInstance
struct UBP_PandoraPickerLibraryLibrary_GetInstance_Params
{
	class UBP_PandoraPickerLibraryLibrary*             ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_SetVideoExportQuality
struct UBP_PandoraPickerLibraryLibrary_BP_SetVideoExportQuality_Params
{
	int                                                Quality;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_PandoraPickerLoadImageTest
struct UBP_PandoraPickerLibraryLibrary_BP_PandoraPickerLoadImageTest_Params
{
	struct FString                                     fImagePath;                                               // (Parm, ZeroConstructor)
	struct FString                                     fOrgImagePath;                                            // (Parm, ZeroConstructor)
	class UTexture2D*                                  orgTex2D;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	class UTexture2D*                                  ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_PandoraPickerInit
struct UBP_PandoraPickerLibraryLibrary_BP_PandoraPickerInit_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_PandoraPickerGetSavedPath
struct UBP_PandoraPickerLibraryLibrary_BP_PandoraPickerGetSavedPath_Params
{
	struct FString                                     strSavePath;                                              // (Parm, OutParm, ZeroConstructor)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_OpenImageLibraryWithOrg
struct UBP_PandoraPickerLibraryLibrary_BP_OpenImageLibraryWithOrg_Params
{
	int                                                Width;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Height;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     SecretKey;                                                // (Parm, ZeroConstructor)
	struct FString                                     SavedPath;                                                // (Parm, ZeroConstructor)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_OpenImageLibraryVideo
struct UBP_PandoraPickerLibraryLibrary_BP_OpenImageLibraryVideo_Params
{
	struct FString                                     SecretKey;                                                // (Parm, ZeroConstructor)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_OpenImageLibraryNoCut
struct UBP_PandoraPickerLibraryLibrary_BP_OpenImageLibraryNoCut_Params
{
	int                                                Width;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Height;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     SecretKey;                                                // (Parm, ZeroConstructor)
	struct FString                                     SavedPath;                                                // (Parm, ZeroConstructor)
};

// Function PandoraPickerPlugin.BP_PandoraPickerLibraryLibrary.BP_OpenImageLibrary
struct UBP_PandoraPickerLibraryLibrary_BP_OpenImageLibrary_Params
{
	int                                                Width;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Height;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     SecretKey;                                                // (Parm, ZeroConstructor)
	struct FString                                     SavedPath;                                                // (Parm, ZeroConstructor)
};

}

