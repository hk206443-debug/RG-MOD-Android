/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:51 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Classes
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Class HiggsBoson.BaziState
// 0x0168 (0x0190 - 0x0028)
class UBaziState : public UObject
{
public:
	unsigned char                                      UnknownData00[0x168];                                     // 0x0028(0x0168) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.BaziState");
		return pStaticClass;
	}


	void OnControllerReconnected();
	void AddChori(const struct FChori& Element);
	void AddBazi(const struct FBazi& Element);
};


// Class HiggsBoson.ClientGlueHiaSystem
// 0x0530 (0x0560 - 0x0030)
class UClientGlueHiaSystem : public UWorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x64];                                      // 0x0030(0x0064) MISSED OFFSET
	bool                                               bEnglish;                                                 // 0x0094(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x0095(0x0003) MISSED OFFSET
	class UBaziState*                                  BaziState;                                                // 0x0098(0x0008) (ZeroConstructor, IsPlainOldData)
	class UMakeWoe*                                    MakeWoe;                                                  // 0x00A0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4B8];                                     // 0x00A8(0x04B8) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.ClientGlueHiaSystem");
		return pStaticClass;
	}


	float Vulou();
	void LuaFunc9(int Param1);
	bool LuaFunc8(int Param1);
	bool LuaFunc7(int Param1);
	bool LuaFunc6(int Param1);
	bool LuaFunc5(int Param1);
	bool LuaFunc4(int Param1);
	void LuaFunc3(int Param1);
	void LuaFunc2();
	bool LuaFunc1(class AActor* PtrActor);
	void Func9(class AActor* PtrWeapon);
	int Func8(class AActor* PtrWeapon, const struct FBulletHitInfoUploadData& UploadData, const struct FLocalShootHitData& LocalHitData);
	bool Func7();
	float Func6(class AActor* Param1);
	float Func3();
	void Func29(class UWorld* World, const struct FBulletHitInfoUploadDataInReplay& HitData, float DrawRadius, float DisplayTime, bool bDrawVictimBound);
	void Func28(class AActor* Weapon, const struct FBulletHitInfoUploadData& BulletHitInfoUploadData, const struct FLocalShootHitData& LocalShootHitData);
	void Func27(uint32_t ShootID);
	void Func26(class AActor* Param4, class AActor* Param5);
	void Func25(int Param1, float Param2, float param3, class AActor* Param4, class AActor* Param5);
	void Func24(int Param1, float Param2, float param3, float Param4, class AActor* Param5, class AActor* Param6);
	void Func23(uint32_t Param1, const struct FVector& Param2, const struct FHitResult& param3);
	void Func22(uint32_t Param1, const struct FVector& Param2, const struct FVector& param3);
	void Func21(class AActor* Param1);
	void Func20(class AActor* Param1, struct FVector* Param2);
	bool Func2(class AActor* CharacterPtr, bool bParam1);
	void Func19(uint32_t Param1, float Param2, float param3);
	void Func18(TArray<struct FBazi> Bazi, TArray<struct FChori> Chori);
	void Func17(const struct FFatalDamageParameter& Param1);
	void Func16();
	void Func15(class AActor* Param1);
	void Func14(const struct FShootTimeData& InData, class AActor* PtrWeapon);
	float Func11(class AActor* Param1);
	void Func10(class AActor* Param1);
	bool Func1(class AActor* CharacterPtr, float TimeInSeconds, float MarginInSeconds);
};


// Class HiggsBoson.FuzzyObject
// 0x0328 (0x0350 - 0x0028)
class UFuzzyObject : public UObject
{
public:
	unsigned char                                      UnknownData00[0x320];                                     // 0x0028(0x0320) MISSED OFFSET
	int                                                Param1;                                                   // 0x0348(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x034C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.FuzzyObject");
		return pStaticClass;
	}


	bool SetUInt8ValueByName(int Name, unsigned char Value);
	bool SetUInt64ValueByName(int Name, uint64_t Value);
	bool SetUInt32ValueByName(int Name, uint32_t Value);
	bool SetUInt16ValueByName(int Name, uint16_t Value);
	bool SetInt8ValueByName(int Name, int8_t Value);
	bool SetInt64ValueByName(int Name, int64_t Value);
	bool SetInt32ValueByName(int Name, int Value);
	bool SetInt16ValueByName(int Name, int16_t Value);
	bool SetFloatValueByName(int Name, float Value);
	bool SetBoolValueByName(int Name, bool Value);
	bool GetUInt8ValueByName(int Name, unsigned char* OutValue);
	bool GetUInt64ValueByName(int Name, uint64_t* OutValue);
	bool GetUInt32ValueByName(int Name, uint32_t* OutValue);
	bool GetUInt16ValueByName(int Name, uint16_t* OutValue);
	bool GetInt8ValueByName(int Name, int8_t* OutValue);
	bool GetInt64ValueByName(int Name, int64_t* OutValue);
	bool GetInt32ValueByName(int Name, int* OutValue);
	bool GetInt16ValueByName(int Name, int16_t* OutValue);
	bool GetFloatValueByName(int Name, float* OutValue);
	bool GetBoolValueByName(int Name, bool* OutValue);
};


// Class HiggsBoson.SCoronaClientData
// 0x0000 (0x0350 - 0x0350)
class USCoronaClientData : public UFuzzyObject
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.SCoronaClientData");
		return pStaticClass;
	}

};


// Class HiggsBoson.ClientAmaUbaSubsystem
// 0x0060 (0x0090 - 0x0030)
class UClientAmaUbaSubsystem : public UWorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x0030(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.ClientAmaUbaSubsystem");
		return pStaticClass;
	}


	void Func1(int IntType, float InTimestamp, int IncreaseCount, bool bAlertUploadFrequency);
};


// Class HiggsBoson.MakeWoe
// 0x0008 (0x0030 - 0x0028)
class UMakeWoe : public UObject
{
public:
	bool                                               bEnable01;                                                // 0x0028(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bEnable02;                                                // 0x0029(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bEnable03;                                                // 0x002A(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x5];                                       // 0x002B(0x0005) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.MakeWoe");
		return pStaticClass;
	}

};


// Class HiggsBoson.FullCoverMarginIntervalCharacterTickerInterval
// 0x0058 (0x0080 - 0x0028)
class UFullCoverMarginIntervalCharacterTickerInterval : public UObject
{
public:
	unsigned char                                      UnknownData00[0x58];                                      // 0x0028(0x0058) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.FullCoverMarginIntervalCharacterTickerInterval");
		return pStaticClass;
	}

};


// Class HiggsBoson.FullCoverMarginIntervalCharacterTicker
// 0x0120 (0x0148 - 0x0028)
class UFullCoverMarginIntervalCharacterTicker : public UObject
{
public:
	float                                              ConfigIntervalTime;                                       // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              ConfigMarginTime;                                         // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0030(0x0008) MISSED OFFSET
	EPawnState                                         SkipPawnState64;                                          // 0x0038(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0039(0x0007) MISSED OFFSET
	TMap<uint32_t, class UFullCoverMarginIntervalCharacterTickerInterval*> CurrentIntervalMap;                                       // 0x0040(0x0050) (ZeroConstructor)
	TMap<uint32_t, struct FPendingJudgeStruct>         PendingJudgeMap;                                          // 0x0090(0x0050) (ZeroConstructor)
	TArray<class UFullCoverMarginIntervalCharacterTickerInterval*> InfoObjectPool;                                           // 0x00E0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData02[0x58];                                      // 0x00F0(0x0058) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.FullCoverMarginIntervalCharacterTicker");
		return pStaticClass;
	}

};


// Class HiggsBoson.CamoyoHelper
// 0x0000 (0x0028 - 0x0028)
class UCamoyoHelper : public UObject
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.CamoyoHelper");
		return pStaticClass;
	}


	static void MakeRectTu(const struct FScriptDelegate& CamoyoRetDelegate, const struct FString& Filename, int Quality, bool bShowUI);
	static void MakeMemPerform(int InbOpen);
	static void MakeFitRectTu(const struct FScriptDelegate& CamoyoRetDelegate, const struct FVector4& InCutParam, int InTuType, bool isShowUI);
};


// Class HiggsBoson.HiggsBosonComponent
// 0x0FB0 (0x11E8 - 0x0238)
class UHiggsBosonComponent : public ULuaActorComponent
{
public:
	unsigned char                                      UnknownData00[0x1F];                                      // 0x0238(0x001F) MISSED OFFSET
	bool                                               bOpenActorChannelErrorReport;                             // 0x0257(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0xF8];                                      // 0x0258(0x00F8) MISSED OFFSET
	struct FString                                     TraceData;                                                // 0x0350(0x0010) (ZeroConstructor)
	struct FString                                     GameTraceData;                                            // 0x0360(0x0010) (ZeroConstructor)
	uint32_t                                           HeartBreaks;                                              // 0x0370(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0374(0x0004) MISSED OFFSET
	struct FString                                     HeartInfo;                                                // 0x0378(0x0010) (ZeroConstructor)
	struct FScriptMulticastDelegate                    OnSwiftHawkDelegate;                                      // 0x0388(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	struct FScriptMulticastDelegate                    OnEzioDelegate;                                           // 0x0398(0x0010) (ZeroConstructor, InstancedReference)
	class ASTExtraBaseCharacter*                       CharacterOwner;                                           // 0x03A8(0x0008) (ZeroConstructor, IsPlainOldData)
	class ASTExtraPlayerController*                    PlayerController;                                         // 0x03B0(0x0008) (ZeroConstructor, IsPlainOldData)
	bool                                               bClientInfoReceived;                                      // 0x03B8(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x03B9(0x0007) MISSED OFFSET
	TArray<uint32_t>                                   ClientInfoAsUInt32Array;                                  // 0x03C0(0x0010) (ZeroConstructor)
	TArray<unsigned char>                              IntegrityItemCheckResultAsBytes;                          // 0x03D0(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData04[0x40];                                      // 0x03E0(0x0040) MISSED OFFSET
	bool                                               bRoofTouchActive;                                         // 0x0420(0x0001) (ZeroConstructor, IsPlainOldData)
	bool                                               bPalmRestActive;                                          // 0x0421(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x12];                                      // 0x0422(0x0012) MISSED OFFSET
	int                                                RoofTouchStatus;                                          // 0x0434(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FString>                             PalmRestSampleKeys;                                       // 0x0438(0x0010) (ZeroConstructor)
	int                                                PalmRestSampleCount;                                      // 0x0448(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData06[0x9C4];                                     // 0x044C(0x09C4) MISSED OFFSET
	class USCoronaClientData*                          SecurityCoronaLabClientDataPointer;                       // 0x0E10(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0x68];                                      // 0x0E18(0x0068) MISSED OFFSET
	bool                                               bMHActive;                                                // 0x0E80(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData08[0xAF];                                      // 0x0E81(0x00AF) MISSED OFFSET
	TMap<int, int>                                     FFItemIDMap;                                              // 0x0F30(0x0050) (ZeroConstructor)
	TMap<int, int>                                     FFWeaponItemIDMap;                                        // 0x0F80(0x0050) (ZeroConstructor)
	unsigned char                                      UnknownData09[0x1C];                                      // 0x0FD0(0x001C) MISSED OFFSET
	int                                                ReceivedRotationModifiedCount;                            // 0x0FEC(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ReceivedTranslationModifiedCount;                         // 0x0FF0(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ReceivedScale3DModifiedCount;                             // 0x0FF4(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<int>                                        LastInvalidIndexListInPakLite;                            // 0x0FF8(0x0010) (ZeroConstructor)
	unsigned char                                      UnknownData10[0x8];                                       // 0x1008(0x0008) MISSED OFFSET
	struct FScriptMulticastDelegate                    OnServerReceiveInvalidFilesInPakLiteDelegate;             // 0x1010(0x0010) (ZeroConstructor, InstancedReference, BlueprintAssignable)
	unsigned char                                      UnknownData11[0xE8];                                      // 0x1020(0x00E8) MISSED OFFSET
	float                                              TouchScreenActiveTimeRatioThreshold;                      // 0x1108(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData12[0x4];                                       // 0x110C(0x0004) MISSED OFFSET
	float                                              MouTa;                                                    // 0x1110(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                BandaCountThreshold;                                      // 0x1114(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bEnableBandCount;                                         // 0x1118(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData13[0x3];                                       // 0x1119(0x0003) MISSED OFFSET
	float                                              IntervalThreshold1;                                       // 0x111C(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                HongThreshold;                                            // 0x1120(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              NovoThreshold;                                            // 0x1124(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData14[0x40];                                      // 0x1128(0x0040) MISSED OFFSET
	int                                                MaxCountOfPlayerHistoryLocationToDetectCamouflage;        // 0x1168(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData15[0xC];                                       // 0x116C(0x000C) MISSED OFFSET
	float                                              MinDistanceToDetectCamouflage;                            // 0x1178(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData16[0x30];                                      // 0x117C(0x0030) MISSED OFFSET
	float                                              OfflineMoveThreshold;                                     // 0x11AC(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              OfflineMoveValidScale;                                    // 0x11B0(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              LongTimeNoReceiveScale;                                   // 0x11B4(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MinOfflineCount;                                          // 0x11B8(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxOfflineCount;                                          // 0x11BC(0x0004) (ZeroConstructor, IsPlainOldData)
	bool                                               bOfflineMoveReady;                                        // 0x11C0(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData17[0x27];                                      // 0x11C1(0x0027) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.HiggsBosonComponent");
		return pStaticClass;
	}


	void Zanwu(const struct FString& Param1);
	void SyncServerParam(bool Param1);
	void SwiftHawk(TArray<unsigned char> Hawks, uint32_t Magic);
	void ShowABCD(const struct FString& Message, bool bIsClientShowWindow);
	void SetSchemeForInitialize(int Index, uint32_t VerifyLen, TArray<unsigned char> VerifyHashArray, TArray<struct FPatchPoint> PatchPointArray);
	void SetSchemeForGet(int Index, uint32_t VerifyLen, TArray<unsigned char> VerifyHashArray, TArray<struct FPatchPoint> PatchPointArray);
	void ServerPoPo(TArray<unsigned char>* Array);
	void SendMoveStatusToServer(EPawnState State);
	void S2CNuoro(int Lotion);
	void RPC_ServerGlueHiaPark(int8_t HiaType, TArray<unsigned char> GlueHiaParkArr, uint32_t HiaStatus, TArray<unsigned char> GlueArg, TArray<unsigned char> GlueHiaParkArr2, uint32_t HiaStatus2);
	void RPC_ServerCapbo(int8_t BoCapC, int8_t InBoType, TArray<unsigned char> BoDataArr);
	void RPC_ServerAddInvalidFilesInPakLite(TArray<int> InvalidIndexList);
	void RPC_ClientCoronaLab(unsigned char bAllSwitch, TArray<unsigned char> CoronaLab, uint32_t CoronaState);
	void OnWeaponAimInput(float InDistToEnemy, float InYaw, float InPitch, float InRoll);
	void OnTouchInput(float InYaw, float InPitch, float InRoll);
	void OnStopFireEvent();
	void OnStartFireEvent();
	void OnSkillInteruptVisual(class AActor* InTarget, class AActor* InCauser);
	void OnSkillEndVisual(class AActor* InTarget, class AActor* InCauser);
	void OnSkillEndTrans(class AActor* InTarget, class AActor* InCauser);
	void OnSkillBeginVisual(class AActor* InTarget, class AActor* InCauser);
	void OnSkillBeginTrans(class AActor* InTarget, class AActor* InCauser);
	void OnRecoilCurveCheckFailed(class AActor* Weapon);
	void OnPlayerScopeOut(bool bBegan);
	void OnPlayerScopeIn(bool bBegan);
	void OnMyPawnRespawn(class AUAEPlayerController* InPlayerController);
	void OnKillSomeOneEvent(class AActor* InSomeOne);
	void OnGyroInput(float InYaw, float InPitch, float InRoll);
	void OnClientAdjustPosition(const struct FVector& NewLoc, ECharacterMoveDragReason Reason);
	void OnCapboReturn(int BoCapC, int InBoType, TArray<unsigned char> RetData);
	void OnBulletImpactEvent(class AActor* InCauser, const struct FHitResult& InImpactResult);
	bool IsCharacterOwnerWerewolf();
	bool IsCharacterOwnerButcher();
	void HandleClientReconnect();
	void FlushGameEnd();
	void Ezio(int Param1, int Param2, int param3, int Param4);
	int EnableTickEncrypt();
	int EnablePeekShootVerify();
	void EnableEnhancedDynamicActors(int Index);
	int EnableCheckFilesInPakLite(TArray<struct FString> InFiles, int InVerifyCountSinglePass);
	void DispatchIntegrityCheckItem(uint32_t PlatID, uint32_t AreaID, uint32_t GameBits, uint32_t Index, int Offset, uint32_t Len, uint32_t Type);
	void DevPVSCheckClientLocationC2S(class ASTExtraBaseCharacter* PtrOtherCharacter, const struct FVector& D, const struct FVector& A, const struct FVector& V, const struct FVector& C, bool b1);
	void DevPVSCheckClientLocation(class AActor* PtrSimulatedProxy, const struct FVector& D);
	void DevPrintMouke(const struct FString& Param0, float Param1, const struct FString& param3);
	void ControlRoofTouch(int Switch);
	void ControlPalmRest(int Switch);
	void ControlMoveInputRecord(int Switch, float RecordCooldown, int BitmapSize, int MinValidSampleCount, uint32_t InAngleSampleMaxCount, uint32_t InAngleDistributionNum);
	void ControlMHActive(int Switch);
	void Cofew(uint32_t InIter);
	void ClientSwiftHawkWithParams(TArray<unsigned char> Hawks);
	void ClientSwiftHawk(unsigned char Type, int SequenceID);
	void ClientReceiveEx(TArray<unsigned char> RPCConstArray);
	void ClientDoJT(bool bDelayUntilShot);
	void ClientCloseBaziUI(TArray<struct FBazi> Bazi, TArray<struct FChori> Chori);
	void ClientAccom(uint16_t Owea);
	void C2SSendAlert(const struct FString& Param1);
};


// Class HiggsBoson.HiggsBosonDataSubsystem
// 0x0110 (0x0140 - 0x0030)
class UHiggsBosonDataSubsystem : public UGameInstanceSubsystem
{
public:
	bool                                               bFingerTouchFlowServerEnabled;                            // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	struct FFingerTouchFlow                            FingerTouchFlow;                                          // 0x0038(0x0098)
	int                                                FingerTouchFlow_MinSampleCount;                           // 0x00D0(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                FingerTouchFlow_MaxClusterCount;                          // 0x00D4(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              FingerTouchFlow_SamplingDuration;                         // 0x00D8(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              FingerTouchFlow_CoolDown;                                 // 0x00DC(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                FingerTouchFlow_MaxSamplePerCluster;                      // 0x00E0(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x00E4(0x0004) MISSED OFFSET
	unsigned char                                      UnknownData02[0x50];                                      // 0x00E4(0x0050) UNKNOWN PROPERTY: SetProperty HiggsBoson.HiggsBosonDataSubsystem.FingerTouchFlow_ModeFilter
	int                                                FingerTouchFlow_AuxResult;                                // 0x0138(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x013C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.HiggsBosonDataSubsystem");
		return pStaticClass;
	}

};


// Class HiggsBoson.HiggsBosonScriptHelper
// 0x0000 (0x0028 - 0x0028)
class UHiggsBosonScriptHelper : public UObject
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.HiggsBosonScriptHelper");
		return pStaticClass;
	}


	static void FileCRCGuard_UnregisterFile(const struct FString& InFilePath);
	static bool FileCRCGuard_RegisterFile(const struct FString& InFilePath, const struct FString& InTag);
};


// Class HiggsBoson.MarginIntervalCharacterTickerPlayerInfo
// 0x0010 (0x0038 - 0x0028)
class UMarginIntervalCharacterTickerPlayerInfo : public UObject
{
public:
	unsigned char                                      UnknownData00[0x10];                                      // 0x0028(0x0010) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.MarginIntervalCharacterTickerPlayerInfo");
		return pStaticClass;
	}

};


// Class HiggsBoson.MarginIntervalCharacterTicker
// 0x0060 (0x0088 - 0x0028)
class UMarginIntervalCharacterTicker : public UObject
{
public:
	float                                              IntervalTime;                                             // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	float                                              MarginTime;                                               // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
	EPawnState                                         SkipPawnState64;                                          // 0x0030(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0031(0x0007) MISSED OFFSET
	TMap<uint32_t, class UMarginIntervalCharacterTickerPlayerInfo*> PlayerKey2Info;                                           // 0x0038(0x0050) (ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.MarginIntervalCharacterTicker");
		return pStaticClass;
	}


	void Reset();
};


// Class HiggsBoson.SecurityAvatarSystem
// 0x0060 (0x0090 - 0x0030)
class USecurityAvatarSystem : public UWorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x60];                                      // 0x0030(0x0060) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.SecurityAvatarSystem");
		return pStaticClass;
	}


	void OnAvatarRectifyDataChange(class AUAECharacter* CharacterOwner, int ItemId);
	void OnAvatarEquipped(class AUAECharacter* CharacterOwner, int SlotID, const struct FItemDefineID& NewItemID, const struct FItemDefineID& OldItemID);
};


// Class HiggsBoson.SecurityImprisonComp
// 0x0030 (0x01A8 - 0x0178)
class USecurityImprisonComp : public UActorComponent
{
public:
	class ASTExtraPlayerController*                    OwnerPC;                                                  // 0x0178(0x0008) (ZeroConstructor, IsPlainOldData)
	class ASTExtraBaseCharacter*                       CharacterWaitForOp;                                       // 0x0180(0x0008) (ZeroConstructor, IsPlainOldData)
	TArray<uint64_t>                                   TeammateKillerUID;                                        // 0x0188(0x0010) (Net, ZeroConstructor)
	TArray<ETeammateHurtType>                          TeammateKillType;                                         // 0x0198(0x0010) (Net, ZeroConstructor)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.SecurityImprisonComp");
		return pStaticClass;
	}


	void ReleaseTeammate(uint64_t PlayerUID);
	void ImprisonmentUIUpdate(uint64_t PlayerUID, bool bIsImprison);
	void ImprisonmentTeammate(uint64_t PlayerUID, bool bIscomplaint);
	void ImprisonmentReport(uint64_t PlayerUID);
};


// Class HiggsBoson.TickAsTimer
// 0x0000 (0x0028 - 0x0028)
class UTickAsTimer : public UObject
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.TickAsTimer");
		return pStaticClass;
	}

};


// Class HiggsBoson.TimeIntervalPawnStateHistorySystem
// 0x00D0 (0x00F8 - 0x0028)
class UTimeIntervalPawnStateHistorySystem : public UObject
{
public:
	unsigned char                                      UnknownData00[0x50];                                      // 0x0028(0x0050) MISSED OFFSET
	int                                                HistoryArraySize;                                         // 0x0078(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7C];                                      // 0x007C(0x007C) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class HiggsBoson.TimeIntervalPawnStateHistorySystem");
		return pStaticClass;
	}


	void UpdateParams();
	bool QueryHistoryMaxVelocity(uint64_t UID, float CenterTime, float MarginTime, float* OutMaxZVelocity, float* OutMaxXYVelocity);
};


}

