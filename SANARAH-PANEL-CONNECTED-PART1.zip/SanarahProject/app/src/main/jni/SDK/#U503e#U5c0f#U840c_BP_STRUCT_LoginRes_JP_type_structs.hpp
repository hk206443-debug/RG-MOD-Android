/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:56 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_LoginRes_JP_type.BP_STRUCT_LoginRes_JP_type
// 0x0078
struct FBP_STRUCT_LoginRes_JP_type
{
	struct FString                                     BeginTime_0_0F090980218B2946494BF95502A77645;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     EndTime_1_6B4516006A156AAE25EA8D900A86CCE5;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_2_50738FC076C94E4B442EA0AA0CF64DF4;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     ResPath_3_635D1A4068185A1130B0C9FA0A070C68;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BGMPath_4_3B02C540543AB0B976689FCC048D0C78;               // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     TexPath_5_77A01C0034346CD406A5B6EA08020C68;               // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     VideoPath_6_5A2C6D801D9EEB6E05DF257105E0A698;             // 0x0058(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ResLodPath_7_13D5820006C2ED2C5D662BAB0515C838;            // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

