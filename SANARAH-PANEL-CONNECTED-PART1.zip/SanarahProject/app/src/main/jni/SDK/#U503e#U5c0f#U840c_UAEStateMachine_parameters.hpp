/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:54 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Parameters
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// Function UAEStateMachine.UAEStateMachineComponent.Start
struct UUAEStateMachineComponent_Start_Params
{
};

// Function UAEStateMachine.UAEStateMachineComponent.SetTag
struct UUAEStateMachineComponent_SetTag_Params
{
	struct FString                                     InTag;                                                    // (Parm, ZeroConstructor)
};

// DelegateFunction UAEStateMachine.UAEStateMachineComponent.OnTransientEvent__DelegateSignature
struct UUAEStateMachineComponent_OnTransientEvent__DelegateSignature_Params
{
	struct FString                                     TransientEvent;                                           // (Parm, ZeroConstructor)
	struct FString                                     CurrentState;                                             // (Parm, ZeroConstructor)
	struct FString                                     TransientToState;                                         // (Parm, ZeroConstructor)
};

// Function UAEStateMachine.UAEStateMachineComponent.IsInState
struct UUAEStateMachineComponent_IsInState_Params
{
	struct FString                                     StateName;                                                // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function UAEStateMachine.UAEStateMachineComponent.GetCurrentState
struct UUAEStateMachineComponent_GetCurrentState_Params
{
	class UUAEState*                                   ReturnValue;                                              // (ExportObject, Parm, OutParm, ZeroConstructor, ReturnParm, InstancedReference, IsPlainOldData)
};

// Function UAEStateMachine.UAEStateMachineComponent.ForceDoEvent
struct UUAEStateMachineComponent_ForceDoEvent_Params
{
	struct FString                                     EventName;                                                // (Parm, ZeroConstructor)
};

// Function UAEStateMachine.UAEStateMachineComponent.Finish
struct UUAEStateMachineComponent_Finish_Params
{
};

// Function UAEStateMachine.UAEStateMachineComponent.DoEvent
struct UUAEStateMachineComponent_DoEvent_Params
{
	struct FString                                     EventName;                                                // (Parm, ZeroConstructor)
};

// Function UAEStateMachine.UAEStateMachineComponent.CanDoEvent
struct UUAEStateMachineComponent_CanDoEvent_Params
{
	struct FString                                     EventName;                                                // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function UAEStateMachine.UAEState.Update
struct UUAEState_Update_Params
{
	float                                              DeltaTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function UAEStateMachine.UAEState.OnLeave
struct UUAEState_OnLeave_Params
{
	class UUAEState*                                   TranitToState;                                            // (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// Function UAEStateMachine.UAEState.OnEnter
struct UUAEState_OnEnter_Params
{
	class UUAEState*                                   PrevState;                                                // (ConstParm, Parm, ZeroConstructor, InstancedReference, IsPlainOldData)
};

}

