/*
================================
Developer: SENARAH
Telegram: @rasa_TDM
Version: Modified Edition
================================
*/

#pragma once

// SDK集成工具By倾小萌 - @BYXiaoSunSun (KR4.7.0 -- 64Bit) SDK 工具 By 倾小萌 @BYXiaoSunSun
// Telegram频道:- @SunSha5201314 提笔绘山河，合卷藏风月，平生志与意，尽在墨痕间。
// 此文件生成时间Fri Nov 13 01:21:55 2026
 
namespace SDK
{
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
//Script Structs
//---------------------By 倾小萌 @BYXiaoSunSun---------------------------
// UserDefinedStruct BP_STRUCT_LinkStyleRes_type.BP_STRUCT_LinkStyleRes_type
// 0x0060
struct FBP_STRUCT_LinkStyleRes_type
{
	int                                                FontSize_0_A45833814314772AA0F40587CB0DD2DB;              // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     StyleName_1_01B6B5F543AB25F3AC37A48BDB25594A;             // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               UnderLine_2_89F7D6C64387435409BA1A84421C6F57;             // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x0019(0x0007) MISSED OFFSET
	struct FString                                     FontColor_3_D2BCBAE447301225879E948D36B9BD28;             // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     FontPath_4_0A5E92CA4BB4DAF4821590AD6C060516;              // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     UnderlineHovered_5_424C54807C6FD1C2456BD6E903FBBD94;      // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     UnderlineNormal_6_32EFDB8066C6BB726F251E7E03A0042C;       // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

