#ifndef LOGIN_H
#define LOGIN_H

#include "Includes.h"
#include "obfuscate.h"
#include <string>

// Authentication state is set only after the RG MOD panel confirms the key.
bool check = false;
bool bValid = false;
bool xEnv = false;
std::string g_Auth;
std::string g_Token;
std::string EXP;

bool signValid = false;

int REI_HttpsCanay_Closed() {
    JavaVM *vm;
    jclass clazz;
    JavaVM* java_vm = vm;
    JNIEnv* java_env = NULL;
    jint jni_return = java_vm->GetEnv((void**)&java_env, JNI_VERSION_1_6);
    if (jni_return == JNI_ERR)
        return -1;
    jni_return = java_vm->AttachCurrentThread(&java_env, NULL);
    if (jni_return != JNI_OK)
        return -2;
    jclass handlerClass = java_env->GetObjectClass(clazz);
    if (handlerClass == NULL)
        return -3;
    jmethodID method_id = java_env->GetMethodID(handlerClass, OBFUSCATE("AndroidThunkJava_RestartGame"), OBFUSCATE("()V"));
    if (method_id == NULL)
        return -4;
    java_env->CallVoidMethod(clazz, method_id);
    jni_return = java_vm->DetachCurrentThread();
    if (jni_return != JNI_OK)
        return -5;
    return 0;
}


bool SecherREI(const std::string& folderPath) {
    return (access(folderPath.c_str(), F_OK) == 0);
}

void Detected_REIHttpCanary() {
    std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.guoshi.httpcanary");
    if (SecherREI(folderPath)) {
        REI_HttpsCanay_Closed();
    }
}
void Detected_REIHttpCanary1() {
    std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.guoshi.httpcanary.premium");
    if (SecherREI(folderPath)) {
        REI_HttpsCanay_Closed();
    }
}
void Detected_REIHttpCanary2() {
    std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.sniffer");
    if (SecherREI(folderPath)) {
        REI_HttpsCanay_Closed();
    }
}

void Detected_REIHttpCanary3() {
    std::string folderPath = OBFUSCATE("/storage/emulated/0/Android/data/com.httpcanary.pro");
    if (SecherREI(folderPath)) {
        REI_HttpsCanay_Closed();
    } else {

    }
}
#endif