package mo.n5la.server;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * RG MOD activation API client.
 *
 * This class talks to the RG MOD PHP endpoint:
 * https://jssjshbw.kesug.com/verify.php
 *
 * Call validateCode() from a background thread, NOT the Android main/UI thread.
 */
public final class RGModApi {

    private static final String VALIDATE_URL =
            "https://jssjshbw.kesug.com/verify.php";

    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 15000;

    private RGModApi() {
        // Utility class; do not create instances.
    }

    /**
     * Sends an activation code to the PHP API.
     *
     * Expected request JSON: {"code":"YOUR_CODE"}
     * Expected response JSON: {"valid":true/false,"message":"..."}
     *
     * @param activationCode activation code entered by the user
     * @return server JSON response. On connection/error, returns
     *         {"ok":false,"message":"..."}.
     */
    public static JSONObject validateCode(String activationCode) {
        if (activationCode == null || activationCode.trim().isEmpty()) {
            return errorResult("يرجى إدخال كود التفعيل");
        }

        HttpURLConnection connection = null;

        try {
            URL url = new URL(VALIDATE_URL);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setDoOutput(true);
            connection.setRequestProperty(
                    "Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");

            JSONObject requestBody = new JSONObject();
            requestBody.put("code", activationCode.trim());

            byte[] body = requestBody.toString().getBytes(StandardCharsets.UTF_8);

            try (OutputStream output = connection.getOutputStream()) {
                output.write(body);
                output.flush();
            }

            int statusCode = connection.getResponseCode();
            InputStream stream = (statusCode >= 200 && statusCode < 300)
                    ? connection.getInputStream()
                    : connection.getErrorStream();

            if (stream == null) {
                return errorResult("السيرفر لم يرجع استجابة");
            }

            StringBuilder responseText = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    responseText.append(line);
                }
            }

            JSONObject response = new JSONObject(responseText.toString());

            // The PHP endpoint returns "valid" and "message".
            if (!response.has("valid")) {
                return errorResult("صيغة استجابة السيرفر غير صحيحة");
            }

            return response;

        } catch (Exception e) {
            return errorResult("تعذر الاتصال بالسيرفر: " + e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private static JSONObject errorResult(String message) {
        JSONObject result = new JSONObject();
        try {
            result.put("valid", false);
            result.put("message", message);
        } catch (Exception ignored) {
            // JSONObject creation should not fail for these simple values.
        }
        return result;
    }
}
